/*  -- AppInsight Master Process   -- */
/*  -- Written 06/05/2015 - MCH   -- */
/*  -- Purpose: Continually Generate up to Date AppInsight table   -- */ 

IF OBJECT_ID(N'master..AppInsight', N'U') IS NULL
	BEGIN
		CREATE DATABASE AppInsight;
	END

IF OBJECT_ID(N'master..AppInsight', N'U') IS NOT NULL
	BEGIN
		TRUNCATE TABLE AppInsight;
		SELECT 'YEA! You''re good to go!';
	END		
	
	SELECT * FROM dbo.AppInsight;

	DECLARE @debug  VARCHAR(2);
	DECLARE @auto VARCHAR (2);

SET @debug=0;
SET @auto=1;

--@auto:  if 0 = only run the @debug command
--@auto:  if 1 = run all below in series
--@debug0: drop any temp tables
--@debug1: recreate temp tables
--@debug2: populate msmTemp table
--@debug3: popolate the servicepcTemp table
--@debug4: populate the servicepcQueryTable table
--@debug5: populate the servicepcQueryTable table

--PROCESS BEGINS BELOW
	IF @auto=1
		BEGIN
			SET @debug=0;
			SET @auto=2;
			PRINT('beginning auto creation...');
		END

IF @debug=0
	BEGIN
	
		PRINT('beginning temp table drops...');
		-- First step, drop any temp tables that exist and recreate with updated data
		IF OBJECT_ID(N'tempdb..#msmTemp', N'U') IS NOT NULL
			BEGIN
				DROP TABLE #msmTemp;
			END
		--SELECT * FROM #msmTemp
		IF OBJECT_ID(N'tempdb..#servicepcTemp', N'U') IS NOT NULL
			BEGIN
				DROP TABLE #servicepcTemp; 
			END
	     --SELECT * FROM #servicepcTemp
		IF OBJECT_ID(N'tempdb..#tdtTemp', N'U') IS NOT NULL
			BEGIN
				DROP TABLE #tdtTemp; 
			END
		--SELECT * FROM #tdtTemp
		IF OBJECT_ID(N'tempdb..#servicepcQueryTable', N'U') IS NOT NULL
			BEGIN
				DROP TABLE #servicepcQueryTable;
			END
		--SELECT * FROM #servicepcQueryTable
		IF OBJECT_ID(N'tempdb..#msmQueryTable', N'U') IS NOT NULL
			BEGIN
				DROP TABLE #msmQueryTable;
			END
		--SELECT * FROM #msmQueryTable
		IF OBJECT_ID(N'tempdb..#tempDatabaseList', N'U') IS NOT NULL
			BEGIN
				DROP TABLE #tempDatabaseList;
			END
		--SELECT * FROM #tempDatabaseList
		
	END

	IF @auto=2
			BEGIN
				SET @debug=1;
				SET @auto=3;
			END

IF @debug=1
	BEGIN
	
		PRINT('beginning temp table creations...');
		IF OBJECT_ID(N'tempdb..#AppInsight', N'U') IS NULL
			BEGIN
				CREATE TABLE #AppInsight (
				 primary_key [int] IDENTITY(1,1) NOT NULL
				,PCName [nvarchar](128) NULL
				,name [nvarchar](128) NULL
				,database_id [nvarchar](128) NULL
				,state_desc [nvarchar](128) NULL
				);
			END
		IF OBJECT_ID(N'tempdb..#msmTemp', N'U') IS NULL
			BEGIN
				CREATE TABLE #msmTemp (
					 p_Id INT IDENTITY(1,1) NOT NULL
					,PCName VARCHAR (50)
					,dbName VARCHAR (50)
					,createdOn DATETIME
					,database_id VARCHAR (5)
					,state_desc VARCHAR (25)
				);
			END
		IF OBJECT_ID(N'tempdb..#servicepcTemp', N'U') IS NULL
			BEGIN
				CREATE TABLE #servicepcTemp (
					 p_Id INT IDENTITY(1,1) NOT NULL
					,PCName VARCHAR (50)
					,dbName VARCHAR (50)
					,createdOn DATETIME
					,database_id VARCHAR (5)
					,state_desc VARCHAR (25)
				);
			END
		IF OBJECT_ID(N'tempdb..#msmQueryTable', N'U') IS NULL
			BEGIN
					CREATE TABLE #msmQueryTable(
					 p_Id INT IDENTITY(1,1) NOT NULL
					,sqlString VARCHAR(255)
					,queryType VARCHAR(10)
					,msmToExec VARCHAR(3)
					,serverToExec VARCHAR(15)
					);
			END
		IF OBJECT_ID(N'tempdb..#servicepcQueryTable', N'U') IS NULL
			BEGIN
				CREATE TABLE #servicepcQueryTable(
				 p_Id INT IDENTITY(1,1) NOT NULL
				,sqlString VARCHAR(255)
				,queryType VARCHAR(10)
				,pcToExec VARCHAR(150)
				,dbToExec VARCHAR (150)
				);
			END
		IF OBJECT_ID(N'tempdb..#tempDatabaseList', N'U') IS NULL
			BEGIN
				CREATE TABLE #tempDatabaseList (
				 p_Id INT IDENTITY(1,1) NOT NULL
				,pcName VARCHAR(50)
				,dbName VARCHAR(50)
				,tblName VARCHAR(50)
				,obj_id   VARCHAR(10)
				,db_type VARCHAR(25)
				,create_date DATETIME
				,modify_date DATETIME
				,max_column_id_used VARCHAR(5)
				);
			END
	--END temp Tables
	
	END
	
	IF @auto=3
		BEGIN
			SET @debug=2;
			SET @auto=4;
		END
	
IF @debug=2
	BEGIN
	
		-- For this query you will need to have your cliconfg settings configured to 
		-- INET + INETD (not KEVIN/KEVIND)
		PRINT('beggining the MSM table builds for INET and INETD...');
		INSERT INTO #msmTemp (PCName, dbname, database_id, state_desc)
			SELECT 'INET' AS PCName, name, /*createdOn*/ database_id, state_desc  FROM INET.master.sys.databases
			WHERE name NOT IN ('master','model','tempdb','msdb') AND name NOT LIKE '%reportser%' UNION
			SELECT 'INETD' AS PCName, name, /*createdOn*/ database_id, state_desc  FROM INETD.master.sys.databases
			WHERE name NOT IN ('master','model','tempdb','msdb') AND name NOT LIKE '%reportser%';
		--END MSM Query table by INET/INETD	
		
	END

	IF @auto=4
		BEGIN
			SET @debug=3;
			SET @auto=5;
		END


IF @debug=3
	BEGIN		

			/*Must have cliconfg set for 32/64 + Linked Servers in format "ServicePC#(#) + CommsPC" */
			PRINT('Building servicePCtemp table...');
			INSERT INTO #servicepcTemp (PCName, dbName, database_id, createdOn, state_desc)
				SELECT 'CommsPC' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM CommsPC.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
				SELECT 'ServicePC1' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC1.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
				SELECT 'ServicePC12' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC12.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
				SELECT 'ServicePC13' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC13.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
				SELECT 'ServicePC15' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC15.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
				SELECT 'ServicePC16' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC16.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
				SELECT 'ServicePC17' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC17.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
				SELECT 'ServicePC18' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC18.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
				SELECT 'ServicePC19' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC19.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
				SELECT 'ServicePC2' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC2.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
				SELECT 'ServicePC20' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC20.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
				SELECT 'ServicePC21' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC21.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
				SELECT 'ServicePC3' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC3.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
				SELECT 'ServicePC4' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC4.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
				SELECT 'ServicePC5' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC5.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
				SELECT 'ServicePC8' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC8.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
				SELECT 'ServicePC9' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC9.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb') UNION
	     		SELECT 'ServicePC24' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC24.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb');
	     		/* No linked server access */ --SELECT 'ServicePC22' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC22.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb');
				/* No linked server access */ --SELECT 'ServicePC23' AS PCName, name as dbName, database_id, create_date AS createdOn, state_desc AS sate_desc FROM ServicePC23.master.sys.databases WHERE name NOT IN ('master','model','tempdb','msdb');
		 		-- SELECT * FROM #servicepcTemp
 			-- END byServicePC query table
 			
	END

	IF @auto=5
		BEGIN
			SET @debug=4;
			SET @auto=6;
		END

IF @debug=4
	BEGIN
	
		Print('building the servicePCQueryTable...');
		INSERT INTO #servicepcQueryTable (sqlString, queryType, pcToExec, dbToExec)
			SELECT 'SELECT ''' + PCName + ''' AS pcName, ''' + dbName + ''' AS dbName,  * FROM ' + PCName + 
			'.' + dbName + '.sys.tables ' AS sqlString, 'srvpc' AS queryType, PCName as pcToExec, dbName AS dbToExec FROM #servicepcTemp;
			
		 ---- populate the #msmQueryTable table -- Current Login does not have adequate perms for MSM query 
		 --   INSERT INTO #msmQueryTable (sqlString, queryType)
		 --   SELECT 'SELECT ''' + PCName + ''' AS pcName,  * FROM ' + PCName + '.' + dbName + '.sys.tables' FROM #msmTemp ;
	    	
	END

	IF @auto=6
		BEGIN
			SET @debug=5;
			SET @auto=7;
		END
		
IF @debug=5
BEGIN

	PRINT('Beginning tblSelections...');
		/*** -- Enhance to insert dynamically -- ***/
	
	PRINT('Beginning CommsPC...');
		--SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
		--'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
		--'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='CommsPC';	
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Beginning ServicePC1...');
	--SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
	--'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
	--'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='ServicePC1';
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Beginning ServicePC12...');
		--SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
		--'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
		--'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='ServicePC12'	
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Beginning ServicePC13...');
		--SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
		--'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
		--'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='ServicePC13'			
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Beginning ServicePC15...');
		--SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
		--'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
		--'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='ServicePC15'
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Beginning ServicePC16...');
		--SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
		--'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
		--'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='ServicePC16'	
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Beginning ServicePC17...');
		--SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
		--'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
		--'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='ServicePC17'	
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Beginning ServicePC18...');
		--SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
		--'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
		--'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='ServicePC18' AND dbName NOT LIKE '%report%'	
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Beginning ServicePC19...');
		--SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
		--'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
		--'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='ServicePC19'
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Beginning ServicePC2...');
		SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
		'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
		'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='ServicePC2' AND dbName <> 'TrabonFIR';
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Beginning ServicePC20...');
		--SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
		--'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
		--'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='ServicePC20'
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Beginning ServicePC21...');
		--SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
		--'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
		--'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='ServicePC21'
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Beginning ServicePC3...');
		--SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
		--'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
		--'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='ServicePC3'
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Beginning ServicePC4...');
		--SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
		--'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
		--'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='ServicePC4'
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Beginning ServicePC5...');
		--SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
		--'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
		--'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='ServicePC5'
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Beginning ServicePC8...');
		--SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
		--'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
		--'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='ServicePC8'
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Beginning ServicePC9...');
		--SELECT 'SELECT ''' + PCName + ''' AS [pcName], ''' + dbName + ''' AS [dbName], name as [tblName], object_id AS [obj_id], '+
		--'type_desc AS [db_type], [create_date], [modify_date], [max_column_id_used] FROM  ' + pcName + '.' + dbName + 
		--'.sys.tables UNION' FROM #servicePCtemp WHERE pcName='ServicePC9'
	--Then use above select with insert below
	--INSERT INTO #tempDatabaseList (pcName, dbName, tblName, obj_id, db_type, create_date, modify_date, max_column_id_used)

	PRINT('Statement complete all tables combined...');
		
		--SELECT * FROM #tempDatabaseList;
	
END

	IF @auto=7
		BEGIN
			SET @debug=6;
			SET @auto=8;
		END

IF @debug = 6
	BEGIN

		  SELECT * FROM #servicepcQueryTable; 
		  SELECT * FROM #msmTemp;
		  SELECT * FROM #servicepcTemp; 
		  SELECT * FROM #msmQueryTable; 
		  --SELECT * FROM #tempDatabaseList; 

	END

	IF @auto = 8
	BEGIN
		SET @debug=7;
		SET @auto=8;
	END  

IF @debug = 7
	BEGIN
		PRINT('Finished on auto step #' + @auto) ;
	END